'use client';

import { useState, useEffect } from 'react';
import { Admin } from '@/lib/types';
import { getCurrentAdmin, setCurrentAdmin, isAdminSetupDone } from '@/lib/store';
import { AdminSetup } from '@/components/admin/admin-setup';
import { AdminLogin } from '@/components/admin/admin-login';
import { AdminDashboard } from '@/components/admin/admin-dashboard';
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';
import Link from 'next/link';

export default function AdminPage() {
  const [admin, setAdmin] = useState<Admin | null>(null);
  const [setupDone, setSetupDone] = useState(false);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const savedAdmin = getCurrentAdmin();
    if (savedAdmin) {
      setAdmin(savedAdmin);
    }
    setSetupDone(isAdminSetupDone());
  }, []);

  const handleSetupComplete = (newAdmin: Admin) => {
    setAdmin(newAdmin);
    setCurrentAdmin(newAdmin);
    setSetupDone(true);
  };

  const handleLogin = (loggedInAdmin: Admin) => {
    setAdmin(loggedInAdmin);
    setCurrentAdmin(loggedInAdmin);
  };

  const handleLogout = () => {
    setAdmin(null);
    setCurrentAdmin(null);
  };

  if (!mounted) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="h-12 w-12 rounded-full border-4 border-primary border-t-transparent animate-spin" />
      </div>
    );
  }

  if (admin) {
    return <AdminDashboard admin={admin} onLogout={handleLogout} />;
  }

  return (
    <main className="min-h-screen bg-background flex flex-col">
      <div className="p-4">
        <Link href="/">
          <Button variant="ghost" size="sm">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Rudi Wallet
          </Button>
        </Link>
      </div>
      
      <div className="flex-1 flex items-center justify-center p-4">
        {!setupDone ? (
          <AdminSetup onSetupComplete={handleSetupComplete} />
        ) : (
          <AdminLogin onLogin={handleLogin} />
        )}
      </div>
    </main>
  );
}
