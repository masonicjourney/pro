'use client';

import { useState, useEffect } from 'react';
import { User } from '@/lib/types';
import { getCurrentUser, setCurrentUser, getTransactionsByUserId } from '@/lib/store';
import { WalletHeader } from '@/components/wallet/wallet-header';
import { BalanceCard } from '@/components/wallet/balance-card';
import { ActionButtons } from '@/components/wallet/action-buttons';
import { WithdrawalModal } from '@/components/wallet/withdrawal-modal';
import { ServiceModal } from '@/components/wallet/service-modal';
import { TransactionsList } from '@/components/wallet/transactions-list';
import { UserLogin } from '@/components/auth/user-login';
import { UserRegister } from '@/components/auth/user-register';
import { Button } from '@/components/ui/button';
import { Shield, BarChart3 } from 'lucide-react';
import Link from 'next/link';

export default function WalletPage() {
  const [user, setUser] = useState<User | null>(null);
  const [authMode, setAuthMode] = useState<'login' | 'register'>('login');
  const [withdrawalOpen, setWithdrawalOpen] = useState(false);
  const [serviceType, setServiceType] = useState<'id' | 'passport' | null>(null);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const savedUser = getCurrentUser();
    if (savedUser) {
      setUser(savedUser);
    }
  }, []);

  const handleLogin = (loggedInUser: User) => {
    setUser(loggedInUser);
    setCurrentUser(loggedInUser);
  };

  const handleRegister = (registeredUser: User) => {
    setUser(registeredUser);
    setCurrentUser(registeredUser);
  };

  const handleLogout = () => {
    setUser(null);
    setCurrentUser(null);
  };

  if (!mounted) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="h-12 w-12 rounded-full border-4 border-primary border-t-transparent animate-spin" />
      </div>
    );
  }

  if (!user) {
    return (
      <main className="min-h-screen bg-background flex flex-col">
        <div className="flex-1 flex flex-col items-center justify-center p-4">
          {authMode === 'login' ? (
            <UserLogin
              onLogin={handleLogin}
              onSwitchToRegister={() => setAuthMode('register')}
            />
          ) : (
            <UserRegister
              onRegister={handleRegister}
              onSwitchToLogin={() => setAuthMode('login')}
            />
          )}
          
          <Link href="/admin" className="mt-6">
            <Button variant="ghost" className="text-muted-foreground">
              <Shield className="h-4 w-4 mr-2" />
              Admin Panel
            </Button>
          </Link>
        </div>
      </main>
    );
  }

  const transactions = getTransactionsByUserId(user.id);

  return (
    <main className="min-h-screen bg-background pb-safe">
      <WalletHeader user={user} onLogout={handleLogout} />
      
      <div className="p-4 space-y-4 max-w-lg mx-auto">
        <BalanceCard user={user} />
        
        <ActionButtons
          onWithdrawal={() => setWithdrawalOpen(true)}
          onGetId={() => setServiceType('id')}
          onGetPassport={() => setServiceType('passport')}
        />

        {/* Statistics Link */}
        <Link href="/stats">
          <Button variant="outline" className="w-full flex items-center gap-2">
            <BarChart3 className="h-5 w-5" />
            Angalia Takwimu Zako
          </Button>
        </Link>

        <TransactionsList transactions={transactions} />
      </div>

      <WithdrawalModal
        open={withdrawalOpen}
        onClose={() => setWithdrawalOpen(false)}
        user={user}
      />

      {serviceType && (
        <ServiceModal
          open={!!serviceType}
          onClose={() => setServiceType(null)}
          user={user}
          type={serviceType}
        />
      )}
    </main>
  );
}
