'use client';

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { ArrowLeft, Mail, MessageCircle, Phone, Send } from 'lucide-react';
import Link from 'next/link';
import { useState } from 'react';

export default function SupportPage() {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <main className="min-h-screen bg-background">
      <header className="p-4 border-b border-border">
        <div className="max-w-lg mx-auto flex items-center gap-3">
          <Link href="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="h-5 w-5" />
            </Button>
          </Link>
          <div>
            <h1 className="font-semibold">Support Team</h1>
            <p className="text-sm text-muted-foreground">Tunakusaidia 24/7</p>
          </div>
        </div>
      </header>

      <div className="p-4 max-w-lg mx-auto space-y-4">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Wasiliana Nasi</CardTitle>
            <CardDescription>
              Tuna njia nyingi za kukusaidia. Chagua njia unayoipenda.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <a
              href="tel:+255123456789"
              className="flex items-center gap-3 p-3 rounded-lg bg-muted hover:bg-muted/80 transition-colors"
            >
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                <Phone className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="font-medium">Piga Simu</p>
                <p className="text-sm text-muted-foreground">+255 123 456 789</p>
              </div>
            </a>

            <a
              href="mailto:support@jswallet.co.tz"
              className="flex items-center gap-3 p-3 rounded-lg bg-muted hover:bg-muted/80 transition-colors"
            >
              <div className="h-10 w-10 rounded-full bg-accent/10 flex items-center justify-center">
                <Mail className="h-5 w-5 text-accent" />
              </div>
              <div>
                <p className="font-medium">Tuma Email</p>
                <p className="text-sm text-muted-foreground">support@jswallet.co.tz</p>
              </div>
            </a>

            <a
              href="https://wa.me/255123456789"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 p-3 rounded-lg bg-muted hover:bg-muted/80 transition-colors"
            >
              <div className="h-10 w-10 rounded-full bg-chart-4/10 flex items-center justify-center">
                <MessageCircle className="h-5 w-5 text-chart-4" />
              </div>
              <div>
                <p className="font-medium">WhatsApp</p>
                <p className="text-sm text-muted-foreground">Chat na sisi moja kwa moja</p>
              </div>
            </a>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Tuma Ujumbe</CardTitle>
            <CardDescription>
              Andika tatizo lako na tutakujibu haraka iwezekanavyo.
            </CardDescription>
          </CardHeader>
          <CardContent>
            {submitted ? (
              <div className="text-center py-6">
                <div className="h-12 w-12 rounded-full bg-accent/10 flex items-center justify-center mx-auto mb-3">
                  <Send className="h-6 w-6 text-accent" />
                </div>
                <p className="font-medium">Ujumbe Umetumwa!</p>
                <p className="text-sm text-muted-foreground mt-1">
                  Tutakujibu ndani ya masaa 24.
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Jina Lako</Label>
                  <Input id="name" placeholder="Jina kamili" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" placeholder="email@example.com" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="message">Ujumbe</Label>
                  <Textarea
                    id="message"
                    placeholder="Eleza tatizo lako hapa..."
                    rows={4}
                    required
                  />
                </div>
                <Button type="submit" className="w-full">
                  <Send className="h-4 w-4 mr-2" />
                  Tuma Ujumbe
                </Button>
              </form>
            )}
          </CardContent>
        </Card>
      </div>
    </main>
  );
}
