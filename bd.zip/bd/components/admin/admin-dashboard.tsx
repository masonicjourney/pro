'use client';

import { useState, useEffect } from 'react';
import { Admin, User, Transaction } from '@/lib/types';
import { getUsers, getTransactions, activateUser, deactivateUser, updateUserBalance, saveUser } from '@/lib/store';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import {
  Users,
  Wallet,
  Activity,
  LogOut,
  CheckCircle,
  XCircle,
  Plus,
  Search,
  RefreshCw,
  BarChart3,
} from 'lucide-react';
import { StatsOverview } from '@/components/stats/stats-overview';
import { StatsCharts } from '@/components/stats/stats-charts';

interface AdminDashboardProps {
  admin: Admin;
  onLogout: () => void;
}

export function AdminDashboard({ admin, onLogout }: AdminDashboardProps) {
  const [users, setUsers] = useState<User[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedUser, setSelectedUser] = useState<User | null>(null);
  const [addBalanceModal, setAddBalanceModal] = useState(false);
  const [balanceAmount, setBalanceAmount] = useState('');

  const loadData = () => {
    setUsers(getUsers());
    setTransactions(getTransactions());
  };

  useEffect(() => {
    loadData();
  }, []);

  const filteredUsers = users.filter(
    (user) =>
      user.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.phone.includes(searchQuery)
  );

  const handleActivate = (userId: string) => {
    activateUser(userId);
    loadData();
  };

  const handleDeactivate = (userId: string) => {
    deactivateUser(userId);
    loadData();
  };

  const handleAddBalance = () => {
    if (!selectedUser || !balanceAmount) return;

    updateUserBalance(selectedUser.id, Number(balanceAmount), 'add');
    setAddBalanceModal(false);
    setBalanceAmount('');
    setSelectedUser(null);
    loadData();
  };

  const formatTsh = (amount: number) => {
    return new Intl.NumberFormat('sw-TZ').format(amount);
  };

  const totalBalance = users.reduce((sum, user) => sum + user.balanceTsh, 0);
  const activeUsers = users.filter((user) => user.isActivated).length;
  const pendingUsers = users.filter((user) => !user.isActivated).length;

  const initials = admin.fullName
    .split(' ')
    .map((n) => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-sidebar text-sidebar-foreground p-4">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-sidebar-primary flex items-center justify-center">
              <span className="text-lg font-bold text-sidebar-primary-foreground">JS</span>
            </div>
            <div>
              <h1 className="font-semibold">Admin Panel</h1>
              <p className="text-xs text-sidebar-foreground/70">JS Digital Wallet</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Avatar className="h-9 w-9 border border-sidebar-border">
              <AvatarImage src={admin.photoUrl} alt={admin.fullName} />
              <AvatarFallback className="bg-sidebar-accent text-sidebar-accent-foreground text-sm">
                {initials}
              </AvatarFallback>
            </Avatar>
            <div className="hidden sm:block">
              <p className="text-sm font-medium">{admin.fullName}</p>
              <p className="text-xs text-sidebar-foreground/70">@{admin.username}</p>
            </div>
            <Button
              variant="ghost"
              size="icon"
              onClick={onLogout}
              className="text-sidebar-foreground hover:bg-sidebar-accent"
            >
              <LogOut className="h-5 w-5" />
            </Button>
          </div>
        </div>
      </header>

      {/* Stats */}
      <div className="max-w-6xl mx-auto p-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <Users className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{users.length}</p>
                  <p className="text-xs text-muted-foreground">Watumiaji Wote</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-accent/10 flex items-center justify-center">
                  <CheckCircle className="h-5 w-5 text-accent" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{activeUsers}</p>
                  <p className="text-xs text-muted-foreground">Wameactivated</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-chart-4/10 flex items-center justify-center">
                  <XCircle className="h-5 w-5 text-chart-4" />
                </div>
                <div>
                  <p className="text-2xl font-bold">{pendingUsers}</p>
                  <p className="text-xs text-muted-foreground">Wanasubiri</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <div className="flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-sidebar/10 flex items-center justify-center">
                  <Wallet className="h-5 w-5 text-sidebar" />
                </div>
                <div>
                  <p className="text-lg font-bold">TSh {formatTsh(totalBalance)}</p>
                  <p className="text-xs text-muted-foreground">Jumla ya Salio</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="users" className="space-y-4">
          <TabsList>
            <TabsTrigger value="users" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              Watumiaji
            </TabsTrigger>
            <TabsTrigger value="transactions" className="flex items-center gap-2">
              <Activity className="h-4 w-4" />
              Miamala
            </TabsTrigger>
            <TabsTrigger value="statistics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Takwimu
            </TabsTrigger>
          </TabsList>

          <TabsContent value="users" className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Tafuta mtumiaji..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Button variant="outline" size="icon" onClick={loadData}>
                <RefreshCw className="h-4 w-4" />
              </Button>
            </div>

            <div className="space-y-3">
              {filteredUsers.length === 0 ? (
                <Card>
                  <CardContent className="py-8 text-center">
                    <Users className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                    <p className="text-muted-foreground">Hakuna watumiaji bado</p>
                  </CardContent>
                </Card>
              ) : (
                filteredUsers.map((user) => {
                  const userInitials = user.fullName
                    .split(' ')
                    .map((n) => n[0])
                    .join('')
                    .toUpperCase()
                    .slice(0, 2);

                  return (
                    <Card key={user.id}>
                      <CardContent className="p-4">
                        <div className="flex items-start gap-3">
                          <Avatar className="h-12 w-12 border-2 border-border">
                            <AvatarImage src={user.photoUrl} alt={user.fullName} />
                            <AvatarFallback className="bg-primary/10 text-primary">
                              {userInitials}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <h3 className="font-semibold">{user.fullName}</h3>
                              <Badge
                                variant={user.isActivated ? 'default' : 'secondary'}
                                className={user.isActivated ? 'bg-accent text-accent-foreground' : ''}
                              >
                                {user.isActivated ? 'Activated' : 'Not Activated'}
                              </Badge>
                            </div>
                            <p className="text-sm text-muted-foreground truncate">{user.email}</p>
                            <p className="text-sm text-muted-foreground">{user.phone}</p>
                            <p className="text-lg font-semibold text-primary mt-1">
                              TSh {formatTsh(user.balanceTsh)}
                            </p>
                          </div>
                          <div className="flex flex-col gap-2">
                            {user.isActivated ? (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleDeactivate(user.id)}
                                className="text-destructive border-destructive hover:bg-destructive hover:text-destructive-foreground"
                              >
                                <XCircle className="h-4 w-4 mr-1" />
                                Deactivate
                              </Button>
                            ) : (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleActivate(user.id)}
                                className="text-accent border-accent hover:bg-accent hover:text-accent-foreground"
                              >
                                <CheckCircle className="h-4 w-4 mr-1" />
                                Activate
                              </Button>
                            )}
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                setSelectedUser(user);
                                setAddBalanceModal(true);
                              }}
                            >
                              <Plus className="h-4 w-4 mr-1" />
                              Add Balance
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })
              )}
            </div>
          </TabsContent>

          <TabsContent value="transactions" className="space-y-4">
            {transactions.length === 0 ? (
              <Card>
                <CardContent className="py-8 text-center">
                  <Activity className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                  <p className="text-muted-foreground">Hakuna miamala bado</p>
                </CardContent>
              </Card>
            ) : (
              transactions.map((transaction) => {
                const user = users.find((u) => u.id === transaction.userId);
                return (
                  <Card key={transaction.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-medium">{user?.fullName || 'Unknown'}</p>
                          <p className="text-sm text-muted-foreground">{transaction.type}</p>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">TSh {formatTsh(transaction.amount)}</p>
                          <Badge variant="secondary">{transaction.status}</Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })
            )}
          </TabsContent>

          <TabsContent value="statistics" className="space-y-6">
            <StatsOverview users={users} transactions={transactions} />
            <StatsCharts users={users} transactions={transactions} />
          </TabsContent>
        </Tabs>
      </div>

      {/* Add Balance Modal */}
      <Dialog open={addBalanceModal} onOpenChange={setAddBalanceModal}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Ongeza Salio</DialogTitle>
          </DialogHeader>
          {selectedUser && (
            <div className="space-y-4">
              <div className="flex items-center gap-3 p-3 bg-muted rounded-lg">
                <Avatar className="h-10 w-10">
                  <AvatarImage src={selectedUser.photoUrl} alt={selectedUser.fullName} />
                  <AvatarFallback className="bg-primary/10 text-primary">
                    {selectedUser.fullName.slice(0, 2).toUpperCase()}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="font-medium">{selectedUser.fullName}</p>
                  <p className="text-sm text-muted-foreground">
                    Salio la sasa: TSh {formatTsh(selectedUser.balanceTsh)}
                  </p>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="balanceAmount">Kiasi (TSh)</Label>
                <Input
                  id="balanceAmount"
                  type="number"
                  placeholder="Weka kiasi"
                  value={balanceAmount}
                  onChange={(e) => setBalanceAmount(e.target.value)}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setAddBalanceModal(false)}>
              Ghairi
            </Button>
            <Button onClick={handleAddBalance} disabled={!balanceAmount}>
              Ongeza Salio
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
