'use client';

import { Transaction } from '@/lib/types';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowDownToLine, ArrowUpToLine, CreditCard, FileText, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

interface TransactionsListProps {
  transactions: Transaction[];
}

export function TransactionsList({ transactions }: TransactionsListProps) {
  const formatTsh = (amount: number) => {
    return new Intl.NumberFormat('sw-TZ').format(amount);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('sw-TZ', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getIcon = (type: Transaction['type']) => {
    switch (type) {
      case 'withdrawal':
        return ArrowUpToLine;
      case 'deposit':
        return ArrowDownToLine;
      case 'id_request':
        return CreditCard;
      case 'passport_request':
        return FileText;
      default:
        return Clock;
    }
  };

  const getLabel = (type: Transaction['type']) => {
    switch (type) {
      case 'withdrawal':
        return 'Kutoa Fedha';
      case 'deposit':
        return 'Kuweka Fedha';
      case 'id_request':
        return 'Ombi la ID';
      case 'passport_request':
        return 'Ombi la Passport';
      default:
        return type;
    }
  };

  const getStatusBadge = (status: Transaction['status']) => {
    const variants: Record<Transaction['status'], { variant: 'default' | 'secondary' | 'destructive' | 'outline'; label: string }> = {
      pending: { variant: 'secondary', label: 'Inasubiri' },
      processing: { variant: 'default', label: 'Inashughulikiwa' },
      completed: { variant: 'outline', label: 'Imekamilika' },
      failed: { variant: 'destructive', label: 'Imeshindikana' },
    };
    return variants[status];
  };

  if (transactions.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Historia ya Miamala</CardTitle>
        </CardHeader>
        <CardContent className="text-center py-8">
          <Clock className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground">Hakuna miamala bado</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg">Historia ya Miamala</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {transactions.map((transaction) => {
          const Icon = getIcon(transaction.type);
          const statusBadge = getStatusBadge(transaction.status);

          return (
            <div
              key={transaction.id}
              className="flex items-center gap-3 p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors"
            >
              <div className={cn(
                'h-10 w-10 rounded-full flex items-center justify-center',
                transaction.type === 'withdrawal' ? 'bg-destructive/10 text-destructive' :
                transaction.type === 'deposit' ? 'bg-accent/10 text-accent' :
                'bg-primary/10 text-primary'
              )}>
                <Icon className="h-5 w-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-medium truncate">{getLabel(transaction.type)}</p>
                  <Badge variant={statusBadge.variant} className="text-xs shrink-0">
                    {statusBadge.label}
                  </Badge>
                </div>
                <div className="flex items-center justify-between gap-2 mt-1">
                  <p className="text-xs text-muted-foreground truncate">
                    {transaction.paymentMethod} - {transaction.accountNumber}
                  </p>
                  <p className={cn(
                    'text-sm font-medium shrink-0',
                    transaction.type === 'withdrawal' ? 'text-destructive' : 'text-accent'
                  )}>
                    {transaction.type === 'withdrawal' ? '-' : '+'}TSh {formatTsh(transaction.amount)}
                  </p>
                </div>
                <p className="text-xs text-muted-foreground mt-1">
                  {formatDate(transaction.createdAt)}
                </p>
              </div>
            </div>
          );
        })}
      </CardContent>
    </Card>
  );
}
