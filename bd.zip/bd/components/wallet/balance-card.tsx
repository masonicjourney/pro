'use client';

import { User, USD_RATE } from '@/lib/types';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Eye, EyeOff, TrendingUp } from 'lucide-react';
import { useState } from 'react';
import { Button } from '@/components/ui/button';

interface BalanceCardProps {
  user: User;
}

export function BalanceCard({ user }: BalanceCardProps) {
  const [showBalance, setShowBalance] = useState(true);

  const formatTsh = (amount: number) => {
    return new Intl.NumberFormat('sw-TZ', {
      style: 'decimal',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const formatUsd = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'decimal',
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    }).format(amount);
  };

  const usdBalance = user.balanceTsh / USD_RATE;

  return (
    <Card className="bg-primary text-primary-foreground overflow-hidden relative">
      <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2" />
      <div className="absolute bottom-0 left-0 w-24 h-24 bg-white/5 rounded-full translate-y-1/2 -translate-x-1/2" />
      
      <CardContent className="p-6 relative">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium opacity-90">Salio Lako</span>
            <Badge 
              variant={user.isActivated ? "secondary" : "destructive"} 
              className={user.isActivated 
                ? "bg-accent text-accent-foreground text-xs" 
                : "text-xs"
              }
            >
              {user.isActivated ? 'Activated' : 'Not Activated'}
            </Badge>
          </div>
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setShowBalance(!showBalance)}
            className="text-primary-foreground hover:bg-white/20"
          >
            {showBalance ? <Eye className="h-5 w-5" /> : <EyeOff className="h-5 w-5" />}
          </Button>
        </div>

        <div className="space-y-1">
          <div className="flex items-baseline gap-2">
            <span className="text-4xl font-bold tracking-tight">
              {showBalance ? `TSh ${formatTsh(user.balanceTsh)}` : 'TSh ****'}
            </span>
          </div>
          <div className="flex items-center gap-2 text-primary-foreground/80">
            <TrendingUp className="h-4 w-4" />
            <span className="text-lg font-medium">
              {showBalance ? `$${formatUsd(usdBalance)}` : '$ ****'}
            </span>
            <span className="text-xs opacity-70">USD</span>
          </div>
        </div>

        <div className="mt-4 pt-4 border-t border-white/20">
          <p className="text-xs opacity-70">
            Exchange Rate: TSh {formatTsh(USD_RATE)} = $1 USD
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
