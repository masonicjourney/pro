'use client';

import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { ArrowDownToLine, CreditCard, FileText } from 'lucide-react';

interface ActionButtonsProps {
  onWithdrawal: () => void;
  onGetId: () => void;
  onGetPassport: () => void;
}

export function ActionButtons({ onWithdrawal, onGetId, onGetPassport }: ActionButtonsProps) {
  return (
    <Card>
      <CardContent className="p-4">
        <h3 className="text-sm font-medium text-muted-foreground mb-4">Huduma za Haraka</h3>
        <div className="grid grid-cols-3 gap-3">
          <Button
            variant="outline"
            className="flex flex-col h-auto py-4 gap-2 hover:bg-primary hover:text-primary-foreground transition-colors"
            onClick={onWithdrawal}
          >
            <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
              <ArrowDownToLine className="h-5 w-5 text-primary" />
            </div>
            <span className="text-xs font-medium">Withdrawal</span>
          </Button>

          <Button
            variant="outline"
            className="flex flex-col h-auto py-4 gap-2 hover:bg-accent hover:text-accent-foreground transition-colors"
            onClick={onGetId}
          >
            <div className="h-10 w-10 rounded-full bg-accent/10 flex items-center justify-center">
              <CreditCard className="h-5 w-5 text-accent" />
            </div>
            <span className="text-xs font-medium">Get ID</span>
          </Button>

          <Button
            variant="outline"
            className="flex flex-col h-auto py-4 gap-2 hover:bg-chart-4 hover:text-foreground transition-colors"
            onClick={onGetPassport}
          >
            <div className="h-10 w-10 rounded-full bg-chart-4/10 flex items-center justify-center">
              <FileText className="h-5 w-5 text-chart-4" />
            </div>
            <span className="text-xs font-medium">Get Passport</span>
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
