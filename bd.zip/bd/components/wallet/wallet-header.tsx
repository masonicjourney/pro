'use client';

import { User } from '@/lib/types';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { LogOut, Settings, CheckCircle, AlertCircle } from 'lucide-react';

interface WalletHeaderProps {
  user: User;
  onLogout: () => void;
}

export function WalletHeader({ user, onLogout }: WalletHeaderProps) {
  const initials = user.fullName
    .split(' ')
    .map(n => n[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  return (
    <header className="flex items-center justify-between p-4 bg-card border-b border-border">
      <div className="flex items-center gap-3">
        <div className="relative">
          <Avatar className="h-14 w-14 border-2 border-primary shadow-md">
            <AvatarImage src={user.photoUrl} alt={user.fullName} />
            <AvatarFallback className="bg-primary text-primary-foreground font-semibold text-lg">
              {initials}
            </AvatarFallback>
          </Avatar>
          {/* Status indicator */}
          <div className={`absolute -bottom-1 -right-1 h-5 w-5 rounded-full border-2 border-card flex items-center justify-center ${user.isActivated ? 'bg-success' : 'bg-warning'}`}>
            {user.isActivated ? (
              <CheckCircle className="h-3 w-3 text-success-foreground" />
            ) : (
              <AlertCircle className="h-3 w-3 text-warning-foreground" />
            )}
          </div>
        </div>
        <div>
          <div className="flex items-center gap-2">
            <h2 className="font-semibold text-foreground">{user.fullName}</h2>
            <Badge variant={user.isActivated ? 'default' : 'secondary'} className={`text-xs ${user.isActivated ? 'bg-success text-success-foreground' : 'bg-warning text-warning-foreground'}`}>
              {user.isActivated ? 'Active' : 'Pending'}
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground">{user.phone}</p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" className="text-muted-foreground">
          <Settings className="h-5 w-5" />
        </Button>
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={onLogout}
          className="text-muted-foreground hover:text-destructive"
        >
          <LogOut className="h-5 w-5" />
        </Button>
      </div>
    </header>
  );
}
