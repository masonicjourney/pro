'use client';

import { User } from '@/lib/types';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { AlertCircle, CheckCircle2, CreditCard, FileText } from 'lucide-react';

interface ServiceModalProps {
  open: boolean;
  onClose: () => void;
  user: User;
  type: 'id' | 'passport';
}

export function ServiceModal({ open, onClose, user, type }: ServiceModalProps) {
  const isId = type === 'id';
  const serviceName = isId ? 'Kitambulisho (ID)' : 'Passport';
  const serviceIcon = isId ? CreditCard : FileText;
  const ServiceIcon = serviceIcon;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold flex items-center gap-2">
            <ServiceIcon className="h-5 w-5" />
            Omba {serviceName}
          </DialogTitle>
        </DialogHeader>

        {!user.isActivated ? (
          <div className="space-y-4 text-center py-4">
            <div className="h-16 w-16 rounded-full bg-destructive/10 flex items-center justify-center mx-auto">
              <AlertCircle className="h-8 w-8 text-destructive" />
            </div>
            <div className="space-y-2">
              <p className="text-foreground">
                Huwezi kuomba <strong>{serviceName}</strong> kwasababu account yako haiko activated.
              </p>
              <p className="text-muted-foreground text-sm">
                Tafadhali wasiliana na kiongozi wako wa usajili ili ku-activate account yako au gusa{' '}
                <a href="/support" className="text-primary underline font-medium">
                  hapa
                </a>
                {' '}kupata msaada.
              </p>
            </div>
            <Button onClick={onClose} className="w-full">
              Sawa, Nimeelewa
            </Button>
          </div>
        ) : (
          <div className="space-y-4 text-center py-4">
            <div className="h-16 w-16 rounded-full bg-accent/10 flex items-center justify-center mx-auto">
              <CheckCircle2 className="h-8 w-8 text-accent" />
            </div>
            <div className="space-y-2">
              <p className="text-foreground">
                Ombi lako la <strong>{serviceName}</strong> limepokelewa na linashughulikiwa.
              </p>
              <p className="text-muted-foreground text-sm">
                Tafadhali subiri au wasiliana na{' '}
                <a href="/support" className="text-primary underline font-medium">
                  support team
                </a>
                {' '}ikiwa ombi limechukua muda zaidi ya dakika 15.
              </p>
              <p className="text-xs text-muted-foreground mt-2">
                Asante kwa uvumilivu wako.
              </p>
            </div>
            <Button onClick={onClose} className="w-full">
              Sawa
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
