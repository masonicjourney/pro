'use client';

import { useState } from 'react';
import { User, BANKS, MOBILE_PAYMENTS, Bank, MobilePayment } from '@/lib/types';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { Building2, Smartphone, ArrowRight, AlertCircle, CheckCircle2 } from 'lucide-react';
import { cn } from '@/lib/utils';

interface WithdrawalModalProps {
  open: boolean;
  onClose: () => void;
  user: User;
}

type PaymentOption = Bank | MobilePayment;

export function WithdrawalModal({ open, onClose, user }: WithdrawalModalProps) {
  const [step, setStep] = useState<'select' | 'details' | 'result'>('select');
  const [paymentType, setPaymentType] = useState<'bank' | 'mobile'>('mobile');
  const [selectedOption, setSelectedOption] = useState<PaymentOption | null>(null);
  const [accountNumber, setAccountNumber] = useState('');
  const [amount, setAmount] = useState('');
  const [resultType, setResultType] = useState<'not-activated' | 'processing'>('not-activated');

  const resetForm = () => {
    setStep('select');
    setSelectedOption(null);
    setAccountNumber('');
    setAmount('');
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  const formatTsh = (value: number) => {
    return new Intl.NumberFormat('sw-TZ').format(value);
  };

  const handleSubmit = () => {
    if (!user.isActivated) {
      setResultType('not-activated');
    } else {
      setResultType('processing');
    }
    setStep('result');
  };

  const options = paymentType === 'bank' ? BANKS : MOBILE_PAYMENTS;

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-md max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-semibold">
            {step === 'select' && 'Chagua Njia ya Malipo'}
            {step === 'details' && 'Weka Taarifa za Malipo'}
            {step === 'result' && (resultType === 'not-activated' ? 'Account Haijawashwa' : 'Muamala Unashughulikiwa')}
          </DialogTitle>
        </DialogHeader>

        {step === 'select' && (
          <div className="space-y-4">
            <Tabs value={paymentType} onValueChange={(v) => setPaymentType(v as 'bank' | 'mobile')}>
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="mobile" className="flex items-center gap-2">
                  <Smartphone className="h-4 w-4" />
                  Mobile Money
                </TabsTrigger>
                <TabsTrigger value="bank" className="flex items-center gap-2">
                  <Building2 className="h-4 w-4" />
                  Benki
                </TabsTrigger>
              </TabsList>

              <TabsContent value="mobile" className="mt-4">
                <div className="grid grid-cols-2 gap-3">
                  {MOBILE_PAYMENTS.map((option) => (
                    <Card
                      key={option.id}
                      className={cn(
                        'cursor-pointer transition-all hover:border-primary',
                        selectedOption?.id === option.id && 'border-primary bg-primary/5'
                      )}
                      onClick={() => setSelectedOption(option)}
                    >
                      <CardContent className="p-3 flex flex-col items-center gap-2">
                        <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center">
                          <Smartphone className="h-6 w-6 text-primary" />
                        </div>
                        <span className="text-sm font-medium text-center">{option.name}</span>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="bank" className="mt-4">
                <div className="grid grid-cols-2 gap-3">
                  {BANKS.map((option) => (
                    <Card
                      key={option.id}
                      className={cn(
                        'cursor-pointer transition-all hover:border-primary',
                        selectedOption?.id === option.id && 'border-primary bg-primary/5'
                      )}
                      onClick={() => setSelectedOption(option)}
                    >
                      <CardContent className="p-3 flex flex-col items-center gap-2">
                        <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center">
                          <Building2 className="h-6 w-6 text-primary" />
                        </div>
                        <span className="text-sm font-medium text-center">{option.name}</span>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>

            <Button 
              className="w-full" 
              disabled={!selectedOption}
              onClick={() => setStep('details')}
            >
              Endelea
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </div>
        )}

        {step === 'details' && (
          <div className="space-y-4">
            <Card className="bg-muted/50">
              <CardContent className="p-3 flex items-center gap-3">
                <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                  {paymentType === 'mobile' ? (
                    <Smartphone className="h-5 w-5 text-primary" />
                  ) : (
                    <Building2 className="h-5 w-5 text-primary" />
                  )}
                </div>
                <div>
                  <p className="font-medium">{selectedOption?.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {paymentType === 'mobile' ? 'Mobile Money' : 'Bank Transfer'}
                  </p>
                </div>
              </CardContent>
            </Card>

            <div className="space-y-3">
              <div className="space-y-2">
                <Label htmlFor="account">
                  {paymentType === 'mobile' ? 'Namba ya Simu' : 'Namba ya Account'}
                </Label>
                <Input
                  id="account"
                  type="tel"
                  placeholder={paymentType === 'mobile' ? '0712 345 678' : 'Account Number'}
                  value={accountNumber}
                  onChange={(e) => setAccountNumber(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="amount">Kiasi (TSh)</Label>
                <Input
                  id="amount"
                  type="number"
                  placeholder="Weka kiasi"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
                <p className="text-xs text-muted-foreground">
                  Salio lako: TSh {formatTsh(user.balanceTsh)}
                </p>
              </div>
            </div>

            <div className="flex gap-2">
              <Button variant="outline" onClick={() => setStep('select')} className="flex-1">
                Rudi
              </Button>
              <Button 
                className="flex-1" 
                disabled={!accountNumber || !amount || Number(amount) <= 0}
                onClick={handleSubmit}
              >
                Toa Fedha
              </Button>
            </div>
          </div>
        )}

        {step === 'result' && resultType === 'not-activated' && (
          <div className="space-y-4 text-center py-4">
            <div className="h-16 w-16 rounded-full bg-destructive/10 flex items-center justify-center mx-auto">
              <AlertCircle className="h-8 w-8 text-destructive" />
            </div>
            <div className="space-y-2">
              <p className="text-foreground">
                Huwezi kutoa <strong>TSh {formatTsh(Number(amount))}</strong> kwenda <strong>{accountNumber}</strong> kwasababu account yako haiko activated.
              </p>
              <p className="text-muted-foreground text-sm">
                Tafadhali wasiliana na kiongozi wako wa usajili ili ku-activate account yako au gusa{' '}
                <a href="/support" className="text-primary underline font-medium">
                  hapa
                </a>
                {' '}kupata msaada.
              </p>
            </div>
            <Button onClick={handleClose} className="w-full">
              Sawa, Nimeelewa
            </Button>
          </div>
        )}

        {step === 'result' && resultType === 'processing' && (
          <div className="space-y-4 text-center py-4">
            <div className="h-16 w-16 rounded-full bg-accent/10 flex items-center justify-center mx-auto">
              <CheckCircle2 className="h-8 w-8 text-accent" />
            </div>
            <div className="space-y-2">
              <p className="text-foreground">
                Muamala wako wa <strong>TSh {formatTsh(Number(amount))}</strong> kwenda <strong>{accountNumber}</strong> unashughulikiwa.
              </p>
              <p className="text-muted-foreground text-sm">
                Tafadhali subiri au wasiliana na{' '}
                <a href="/support" className="text-primary underline font-medium">
                  support team
                </a>
                {' '}ikiwa muamala umechukua muda zaidi ya dakika 15.
              </p>
              <p className="text-xs text-muted-foreground mt-2">
                Asante kwa uvumilivu wako.
              </p>
            </div>
            <Button onClick={handleClose} className="w-full">
              Sawa
            </Button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
