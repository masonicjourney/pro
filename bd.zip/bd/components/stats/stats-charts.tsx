"use client";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Transaction, User } from "@/lib/types";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
  Legend,
} from "recharts";

interface StatsChartsProps {
  users: User[];
  transactions: Transaction[];
}

const COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6", "#ec4899"];

export function StatsCharts({ users, transactions }: StatsChartsProps) {
  // Prepare data for transaction types pie chart
  const transactionTypeData = [
    {
      name: "Withdrawals",
      value: transactions.filter((t) => t.type === "withdrawal").length,
    },
    {
      name: "Deposits",
      value: transactions.filter((t) => t.type === "deposit").length,
    },
    {
      name: "ID Services",
      value: transactions.filter((t) => t.type === "id_request").length,
    },
    {
      name: "Passport",
      value: transactions.filter((t) => t.type === "passport_request").length,
    },
  ].filter((d) => d.value > 0);

  // Prepare monthly data
  const monthlyData = getMonthlyData(transactions);

  // User status data
  const userStatusData = [
    { name: "Active", value: users.filter((u) => u.isActivated).length },
    { name: "Inactive", value: users.filter((u) => !u.isActivated).length },
  ].filter((d) => d.value > 0);

  // Payment method distribution
  const paymentMethods = transactions
    .filter((t) => t.type === "withdrawal" && t.paymentMethod)
    .reduce((acc, t) => {
      const method = t.paymentMethod || "Unknown";
      acc[method] = (acc[method] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

  const paymentMethodData = Object.entries(paymentMethods).map(([name, value]) => ({
    name,
    value,
  }));

  return (
    <div className="grid gap-6 md:grid-cols-2">
      {/* Transaction Types Pie Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Aina za Miamala</CardTitle>
          <CardDescription>Mgawanyo wa miamala kwa aina</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            {transactionTypeData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={transactionTypeData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {transactionTypeData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex h-full items-center justify-center text-muted-foreground">
                Hakuna data ya miamala
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* User Status Pie Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Hali ya Watumiaji</CardTitle>
          <CardDescription>Watumiaji waliowashwa vs wasio</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            {userStatusData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={userStatusData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    <Cell fill="#10b981" />
                    <Cell fill="#ef4444" />
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex h-full items-center justify-center text-muted-foreground">
                Hakuna watumiaji
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Monthly Transactions Bar Chart */}
      <Card className="md:col-span-2">
        <CardHeader>
          <CardTitle className="text-lg">Miamala ya Kila Mwezi</CardTitle>
          <CardDescription>Idadi ya miamala kwa miezi 6 iliyopita</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            {monthlyData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlyData}>
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis dataKey="month" className="text-xs" />
                  <YAxis className="text-xs" />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="withdrawals" name="Withdrawals" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="deposits" name="Deposits" fill="#10b981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex h-full items-center justify-center text-muted-foreground">
                Hakuna data ya miezi
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Payment Methods Distribution */}
      {paymentMethodData.length > 0 && (
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg">Njia za Malipo</CardTitle>
            <CardDescription>Usambazaji wa njia za kutoa fedha</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={paymentMethodData} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                  <XAxis type="number" className="text-xs" />
                  <YAxis dataKey="name" type="category" width={100} className="text-xs" />
                  <Tooltip />
                  <Bar dataKey="value" name="Miamala" fill="#8b5cf6" radius={[0, 4, 4, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function getMonthlyData(transactions: Transaction[]) {
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const now = new Date();
  const data = [];

  for (let i = 5; i >= 0; i--) {
    const date = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const monthKey = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`;
    const monthTransactions = transactions.filter((t) => t.createdAt.startsWith(monthKey));

    data.push({
      month: months[date.getMonth()],
      withdrawals: monthTransactions.filter((t) => t.type === "withdrawal").length,
      deposits: monthTransactions.filter((t) => t.type === "deposit").length,
    });
  }

  return data;
}
