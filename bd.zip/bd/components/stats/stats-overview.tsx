"use client";

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { User, Transaction } from "@/lib/types";
import { Users, Wallet, TrendingUp, TrendingDown, CheckCircle, XCircle } from "lucide-react";

interface StatsOverviewProps {
  users: User[];
  transactions: Transaction[];
}

export function StatsOverview({ users, transactions }: StatsOverviewProps) {
  const totalUsers = users.length;
  const activeUsers = users.filter((u) => u.isActivated).length;
  const inactiveUsers = totalUsers - activeUsers;

  const totalBalanceTsh = users.reduce((sum, u) => sum + u.balanceTsh, 0);
  const totalBalanceUsd = users.reduce((sum, u) => sum + u.balanceUsd, 0);

  const totalWithdrawals = transactions
    .filter((t) => t.type === "withdrawal")
    .reduce((sum, t) => sum + t.amount, 0);

  const totalDeposits = transactions
    .filter((t) => t.type === "deposit")
    .reduce((sum, t) => sum + t.amount, 0);

  const pendingTransactions = transactions.filter(
    (t) => t.status === "pending"
  ).length;

  const formatCurrency = (amount: number, currency: string = "TSh") => {
    return `${currency} ${amount.toLocaleString()}`;
  };

  const stats = [
    {
      title: "Watumiaji Wote",
      value: totalUsers,
      icon: Users,
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
    {
      title: "Walio Activated",
      value: activeUsers,
      icon: CheckCircle,
      color: "text-success",
      bgColor: "bg-success/10",
    },
    {
      title: "Hawako Activated",
      value: inactiveUsers,
      icon: XCircle,
      color: "text-destructive",
      bgColor: "bg-destructive/10",
    },
    {
      title: "Jumla ya Salio (TSh)",
      value: formatCurrency(totalBalanceTsh),
      icon: Wallet,
      color: "text-primary",
      bgColor: "bg-primary/10",
    },
    {
      title: "Jumla ya Salio (USD)",
      value: formatCurrency(totalBalanceUsd, "$"),
      icon: Wallet,
      color: "text-accent",
      bgColor: "bg-accent/10",
    },
    {
      title: "Withdrawals",
      value: formatCurrency(totalWithdrawals),
      icon: TrendingDown,
      color: "text-destructive",
      bgColor: "bg-destructive/10",
    },
    {
      title: "Deposits",
      value: formatCurrency(totalDeposits),
      icon: TrendingUp,
      color: "text-success",
      bgColor: "bg-success/10",
    },
    {
      title: "Miamala Inasubiri",
      value: pendingTransactions,
      icon: TrendingUp,
      color: "text-warning",
      bgColor: "bg-warning/10",
    },
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {stats.map((stat, index) => (
        <Card key={index}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">
              {stat.title}
            </CardTitle>
            <div className={`p-2 rounded-full ${stat.bgColor}`}>
              <stat.icon className={`h-4 w-4 ${stat.color}`} />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-xl font-bold">{stat.value}</div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
