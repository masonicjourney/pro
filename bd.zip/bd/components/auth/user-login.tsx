'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Mail, Loader2, Lock, Eye, EyeOff, Phone } from 'lucide-react';
import { loginUser, setCurrentUser } from '@/lib/store';
import type { User } from '@/lib/types';

interface UserLoginProps {
  onLogin: (user: User) => void;
  onSwitchToRegister: () => void;
}

export function UserLogin({ onLogin, onSwitchToRegister }: UserLoginProps) {
  const [emailOrPhone, setEmailOrPhone] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const user = loginUser(emailOrPhone, password);
      if (!user) {
        setError('Email/Simu au password si sahihi. Tafadhali jaribu tena.');
        setLoading(false);
        return;
      }

      setCurrentUser(user);
      onLogin(user);
    } catch (err) {
      setError('Kuna tatizo limetokea. Tafadhali jaribu tena.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
          <span className="text-2xl font-bold text-primary">JS</span>
        </div>
        <CardTitle className="text-2xl">Karibu Tena</CardTitle>
        <CardDescription>Ingia kwenye account yako ya JS Wallet</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <div className="p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
              {error}
            </div>
          )}

          <div className="space-y-2">
            <Label htmlFor="emailOrPhone">Email au Namba ya Simu</Label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="emailOrPhone"
                type="text"
                placeholder="john@example.com au 0712345678"
                value={emailOrPhone}
                onChange={(e) => setEmailOrPhone(e.target.value)}
                className="pl-10"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="password"
                type={showPassword ? 'text' : 'password'}
                placeholder="Weka password yako"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pl-10 pr-10"
                required
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          <Button type="submit" className="w-full" disabled={loading}>
            {loading && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            Ingia
          </Button>

          <p className="text-center text-sm text-muted-foreground">
            Huna account?{' '}
            <button
              type="button"
              onClick={onSwitchToRegister}
              className="text-primary underline font-medium"
            >
              Jisajili
            </button>
          </p>
        </form>
      </CardContent>
    </Card>
  );
}
