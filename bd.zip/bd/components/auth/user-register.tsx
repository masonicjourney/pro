'use client';

import { useState, useRef } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { User as UserIcon, Mail, Phone, Camera, Loader2, Lock, Eye, EyeOff, Upload, X } from 'lucide-react';
import { saveUser, generateId, getUserByEmail, getUserByPhone, setCurrentUser } from '@/lib/store';
import { uploadToImgBB, fileToBase64 } from '@/lib/imgbb';
import type { User } from '@/lib/types';
import Image from 'next/image';

interface UserRegisterProps {
  onRegister: (user: User) => void;
  onSwitchToLogin: () => void;
}

export function UserRegister({ onRegister, onSwitchToLogin }: UserRegisterProps) {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [leader, setLeader] = useState('');
  const [loading, setLoading] = useState(false);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);
  const [error, setError] = useState('');
  const [photoFile, setPhotoFile] = useState<File | null>(null);
  const [photoPreview, setPhotoPreview] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handlePhotoSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    if (!file.type.startsWith('image/')) {
      setError('Tafadhali chagua picha halali (JPG, PNG, GIF)');
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setError('Picha ni kubwa sana. Upeo ni 5MB');
      return;
    }

    setPhotoFile(file);
    setError('');

    // Generate preview
    try {
      const preview = await fileToBase64(file);
      setPhotoPreview(preview);
    } catch {
      setError('Tatizo la kusoma picha');
    }
  };

  const removePhoto = () => {
    setPhotoFile(null);
    setPhotoPreview('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    // Validate passwords
    if (password.length < 6) {
      setError('Password inapaswa kuwa na angalau herufi 6');
      return;
    }

    if (password !== confirmPassword) {
      setError('Passwords hazifanani');
      return;
    }

    setLoading(true);

    try {
      // Check if email exists
      const existingEmail = getUserByEmail(email);
      if (existingEmail) {
        setError('Email hii imeshatumika. Tafadhali tumia email nyingine.');
        setLoading(false);
        return;
      }

      // Check if phone exists
      const existingPhone = getUserByPhone(phone);
      if (existingPhone) {
        setError('Namba hii ya simu imeshatumika.');
        setLoading(false);
        return;
      }

      let photoUrl = '';

      // Upload photo to ImgBB if selected
      if (photoFile) {
        setUploadingPhoto(true);
        try {
          photoUrl = await uploadToImgBB(photoFile);
        } catch (uploadError) {
          console.error('Photo upload failed:', uploadError);
          // Continue without photo if upload fails
          setError('Picha haijapakiwa lakini account itaundwa. Unaweza kuongeza picha baadaye.');
        } finally {
          setUploadingPhoto(false);
        }
      }

      const newUser: User = {
        id: generateId(),
        fullName,
        email,
        password, // Store password
        phone,
        photoUrl,
        balanceTsh: 0,
        balanceUsd: 0,
        isActivated: false,
        registrationLeader: leader,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        lastLogin: new Date().toISOString(),
        totalWithdrawals: 0,
        totalDeposits: 0,
      };

      saveUser(newUser);
      setCurrentUser(newUser);
      onRegister(newUser);
    } catch (err) {
      setError('Kuna tatizo limetokea. Tafadhali jaribu tena.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader className="text-center">
        <div className="h-16 w-16 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-4">
          <span className="text-2xl font-bold text-primary">JS</span>
        </div>
        <CardTitle className="text-2xl">Jisajili</CardTitle>
        <CardDescription>Tengeneza account yako ya JS Wallet</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <div className="p-3 rounded-lg bg-destructive/10 text-destructive text-sm">
              {error}
            </div>
          )}

          {/* Photo Upload */}
          <div className="space-y-2">
            <Label>Picha ya Wasifu</Label>
            <div className="flex items-center gap-4">
              <div className="relative h-20 w-20 rounded-full bg-muted flex items-center justify-center overflow-hidden border-2 border-dashed border-border">
                {photoPreview ? (
                  <>
                    <Image
                      src={photoPreview}
                      alt="Preview"
                      fill
                      className="object-cover"
                    />
                    <button
                      type="button"
                      onClick={removePhoto}
                      className="absolute -top-1 -right-1 h-6 w-6 rounded-full bg-destructive text-destructive-foreground flex items-center justify-center"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </>
                ) : (
                  <Camera className="h-8 w-8 text-muted-foreground" />
                )}
              </div>
              <div className="flex-1">
                <input
                  ref={fileInputRef}
                  type="file"
                  accept="image/*"
                  onChange={handlePhotoSelect}
                  className="hidden"
                  id="photo-upload"
                />
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full"
                >
                  <Upload className="h-4 w-4 mr-2" />
                  {photoFile ? 'Badilisha Picha' : 'Pakia Picha'}
                </Button>
                <p className="text-xs text-muted-foreground mt-1">
                  JPG, PNG, GIF. Upeo 5MB
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="fullName">Jina Kamili</Label>
            <div className="relative">
              <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="fullName"
                placeholder="John Doe"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                className="pl-10"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="email"
                type="email"
                placeholder="john@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="pl-10"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Namba ya Simu</Label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="phone"
                type="tel"
                placeholder="0712 345 678"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="pl-10"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="password"
                type={showPassword ? 'text' : 'password'}
                placeholder="Weka password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="pl-10 pr-10"
                required
                minLength={6}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="confirmPassword">Thibitisha Password</Label>
            <div className="relative">
              <Lock className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                id="confirmPassword"
                type={showConfirmPassword ? 'text' : 'password'}
                placeholder="Rudia password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="pl-10 pr-10"
                required
              />
              <button
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              >
                {showConfirmPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="leader">Jina la Kiongozi wa Usajili</Label>
            <Input
              id="leader"
              placeholder="Jina la kiongozi"
              value={leader}
              onChange={(e) => setLeader(e.target.value)}
              required
            />
          </div>

          <Button type="submit" className="w-full" disabled={loading || uploadingPhoto}>
            {(loading || uploadingPhoto) && <Loader2 className="h-4 w-4 mr-2 animate-spin" />}
            {uploadingPhoto ? 'Inapakia picha...' : loading ? 'Inatengeneza account...' : 'Jisajili'}
          </Button>

          <p className="text-center text-sm text-muted-foreground">
            Una account tayari?{' '}
            <button
              type="button"
              onClick={onSwitchToLogin}
              className="text-primary underline font-medium"
            >
              Ingia
            </button>
          </p>
        </form>
      </CardContent>
    </Card>
  );
}
