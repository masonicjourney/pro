// JS Digital Wallet - Statistics Page JavaScript

// DOM Elements
const userPhoto = document.getElementById('userPhoto');
const avatarFallback = document.getElementById('avatarFallback');
const userName = document.getElementById('userName');
const userPhone = document.getElementById('userPhone');
const statusIndicator = document.getElementById('statusIndicator');
const accountStatus = document.getElementById('accountStatus');
const balanceTsh = document.getElementById('balanceTsh');
const balanceUsd = document.getElementById('balanceUsd');
const totalDeposits = document.getElementById('totalDeposits');
const totalWithdrawals = document.getElementById('totalWithdrawals');
const totalTransactions = document.getElementById('totalTransactions');
const pendingTransactions = document.getElementById('pendingTransactions');
const transactionsList = document.getElementById('transactionsList');
const loginModal = document.getElementById('loginModal');
const loginForm = document.getElementById('loginForm');
const logoutBtn = document.getElementById('logoutBtn');
const togglePassword = document.getElementById('togglePassword');
const loginPassword = document.getElementById('loginPassword');

// Chart instances
let weeklyChart = null;
let distributionChart = null;
let monthlyChart = null;
let transactionTypesChart = null;
let statusChart = null;

// Current user
let currentUser = null;

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
  checkAuth();
  setupEventListeners();
});

// Check authentication
function checkAuth() {
  const userData = localStorage.getItem('js_wallet_current_user');
  if (userData) {
    currentUser = JSON.parse(userData);
    loadUserData();
  } else {
    showLoginModal();
  }
}

// Setup event listeners
function setupEventListeners() {
  // Login form
  loginForm.addEventListener('submit', handleLogin);
  
  // Logout button
  logoutBtn.addEventListener('click', handleLogout);
  
  // Toggle password visibility
  togglePassword.addEventListener('click', function() {
    const type = loginPassword.getAttribute('type');
    loginPassword.setAttribute('type', type === 'password' ? 'text' : 'password');
  });
  
  // Go to register
  document.getElementById('goRegister').addEventListener('click', function(e) {
    e.preventDefault();
    window.location.href = '/';
  });
}

// Handle login
function handleLogin(e) {
  e.preventDefault();
  
  const emailOrPhone = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;
  
  // Get users from localStorage
  const users = JSON.parse(localStorage.getItem('js_wallet_users') || '[]');
  
  // Find user
  const user = users.find(u => 
    (u.email === emailOrPhone || u.phone === emailOrPhone) && u.password === password
  );
  
  if (user) {
    // Update last login
    user.lastLogin = new Date().toISOString();
    localStorage.setItem('js_wallet_users', JSON.stringify(users));
    localStorage.setItem('js_wallet_current_user', JSON.stringify(user));
    
    currentUser = user;
    hideLoginModal();
    loadUserData();
  } else {
    alert('Barua pepe/simu au nenosiri si sahihi!');
  }
}

// Handle logout
function handleLogout() {
  localStorage.removeItem('js_wallet_current_user');
  currentUser = null;
  showLoginModal();
}

// Show login modal
function showLoginModal() {
  loginModal.classList.add('active');
}

// Hide login modal
function hideLoginModal() {
  loginModal.classList.remove('active');
}

// Load user data
function loadUserData() {
  if (!currentUser) return;
  
  // User info
  userName.textContent = currentUser.fullName;
  userPhone.textContent = currentUser.phone;
  
  // User photo
  if (currentUser.photoUrl) {
    userPhoto.src = currentUser.photoUrl;
    userPhoto.classList.add('loaded');
    avatarFallback.style.display = 'none';
  } else {
    const initials = currentUser.fullName
      .split(' ')
      .map(n => n[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
    avatarFallback.textContent = initials;
    avatarFallback.style.display = 'flex';
  }
  
  // Account status
  if (currentUser.isActivated) {
    statusIndicator.classList.add('active');
    accountStatus.textContent = 'Active';
    accountStatus.classList.add('active');
  } else {
    statusIndicator.classList.remove('active');
    accountStatus.textContent = 'Pending';
    accountStatus.classList.remove('active');
  }
  
  // Balance
  balanceTsh.textContent = formatNumber(currentUser.balanceTsh || 0);
  balanceUsd.textContent = formatNumber(currentUser.balanceUsd || 0);
  
  // Load statistics
  loadStatistics();
}

// Load statistics
function loadStatistics() {
  const transactions = getTransactions();
  const userTransactions = transactions.filter(t => t.userId === currentUser.id);
  
  // Calculate totals
  const deposits = userTransactions
    .filter(t => t.type === 'deposit')
    .reduce((sum, t) => sum + t.amount, 0);
  
  const withdrawals = userTransactions
    .filter(t => t.type === 'withdrawal')
    .reduce((sum, t) => sum + t.amount, 0);
  
  const pending = userTransactions.filter(t => t.status === 'pending').length;
  const completed = userTransactions.filter(t => t.status === 'completed').length;
  
  // Update stats
  totalDeposits.textContent = 'TSh ' + formatNumber(deposits);
  totalWithdrawals.textContent = 'TSh ' + formatNumber(withdrawals);
  totalTransactions.textContent = userTransactions.length;
  pendingTransactions.textContent = pending;
  
  // Render charts
  renderWeeklyChart(userTransactions);
  renderDistributionChart(deposits, withdrawals);
  renderMonthlyChart(userTransactions);
  renderTransactionTypesChart(userTransactions);
  renderStatusChart(pending, completed, userTransactions.length - pending - completed);
  
  // Render transactions list
  renderTransactionsList(userTransactions);
}

// Get transactions from localStorage
function getTransactions() {
  return JSON.parse(localStorage.getItem('js_wallet_transactions') || '[]');
}

// Format number
function formatNumber(num) {
  return new Intl.NumberFormat('sw-TZ').format(num);
}

// Render weekly chart
function renderWeeklyChart(transactions) {
  const ctx = document.getElementById('weeklyChart').getContext('2d');
  
  // Get last 7 days
  const days = [];
  const depositsData = [];
  const withdrawalsData = [];
  
  for (let i = 6; i >= 0; i--) {
    const date = new Date();
    date.setDate(date.getDate() - i);
    const dateStr = date.toISOString().split('T')[0];
    
    days.push(date.toLocaleDateString('sw-TZ', { weekday: 'short' }));
    
    const dayTransactions = transactions.filter(t => 
      t.createdAt && t.createdAt.split('T')[0] === dateStr
    );
    
    const dayDeposits = dayTransactions
      .filter(t => t.type === 'deposit')
      .reduce((sum, t) => sum + t.amount, 0);
    
    const dayWithdrawals = dayTransactions
      .filter(t => t.type === 'withdrawal')
      .reduce((sum, t) => sum + t.amount, 0);
    
    depositsData.push(dayDeposits);
    withdrawalsData.push(dayWithdrawals);
  }
  
  // Destroy existing chart
  if (weeklyChart) {
    weeklyChart.destroy();
  }
  
  weeklyChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: days,
      datasets: [
        {
          label: 'Amana',
          data: depositsData,
          backgroundColor: 'rgba(34, 197, 94, 0.8)',
          borderRadius: 4,
        },
        {
          label: 'Kutoa',
          data: withdrawalsData,
          backgroundColor: 'rgba(239, 68, 68, 0.8)',
          borderRadius: 4,
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            usePointStyle: true,
            padding: 15,
            font: { size: 11 }
          }
        }
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: { font: { size: 10 } }
        },
        y: {
          beginAtZero: true,
          grid: { color: 'rgba(0,0,0,0.05)' },
          ticks: {
            font: { size: 10 },
            callback: function(value) {
              return value >= 1000 ? (value/1000) + 'k' : value;
            }
          }
        }
      }
    }
  });
}

// Render distribution chart
function renderDistributionChart(deposits, withdrawals) {
  const ctx = document.getElementById('distributionChart').getContext('2d');
  
  // Destroy existing chart
  if (distributionChart) {
    distributionChart.destroy();
  }
  
  const total = deposits + withdrawals;
  if (total === 0) {
    // Show empty state
    ctx.font = '14px Arial';
    ctx.fillStyle = '#64748b';
    ctx.textAlign = 'center';
    ctx.fillText('Hakuna data', ctx.canvas.width / 2, ctx.canvas.height / 2);
    return;
  }
  
  distributionChart = new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: ['Amana', 'Kutoa'],
      datasets: [{
        data: [deposits, withdrawals],
        backgroundColor: ['rgba(34, 197, 94, 0.8)', 'rgba(239, 68, 68, 0.8)'],
        borderWidth: 0,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            usePointStyle: true,
            padding: 15,
            font: { size: 11 }
          }
        }
      },
      cutout: '60%',
    }
  });
}

// Render monthly chart
function renderMonthlyChart(transactions) {
  const ctx = document.getElementById('monthlyChart').getContext('2d');
  
  // Get last 30 days data grouped by week
  const weeks = ['Wiki 1', 'Wiki 2', 'Wiki 3', 'Wiki 4'];
  const depositsData = [0, 0, 0, 0];
  const withdrawalsData = [0, 0, 0, 0];
  
  const now = new Date();
  transactions.forEach(t => {
    if (!t.createdAt) return;
    
    const transDate = new Date(t.createdAt);
    const daysDiff = Math.floor((now - transDate) / (1000 * 60 * 60 * 24));
    
    if (daysDiff <= 30) {
      const weekIndex = Math.min(3, Math.floor(daysDiff / 7));
      const reversedIndex = 3 - weekIndex;
      
      if (t.type === 'deposit') {
        depositsData[reversedIndex] += t.amount;
      } else if (t.type === 'withdrawal') {
        withdrawalsData[reversedIndex] += t.amount;
      }
    }
  });
  
  // Destroy existing chart
  if (monthlyChart) {
    monthlyChart.destroy();
  }
  
  monthlyChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: weeks,
      datasets: [
        {
          label: 'Amana',
          data: depositsData,
          borderColor: 'rgba(34, 197, 94, 1)',
          backgroundColor: 'rgba(34, 197, 94, 0.1)',
          fill: true,
          tension: 0.4,
          pointRadius: 4,
        },
        {
          label: 'Kutoa',
          data: withdrawalsData,
          borderColor: 'rgba(239, 68, 68, 1)',
          backgroundColor: 'rgba(239, 68, 68, 0.1)',
          fill: true,
          tension: 0.4,
          pointRadius: 4,
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            usePointStyle: true,
            padding: 15,
            font: { size: 11 }
          }
        }
      },
      scales: {
        x: {
          grid: { display: false },
          ticks: { font: { size: 10 } }
        },
        y: {
          beginAtZero: true,
          grid: { color: 'rgba(0,0,0,0.05)' },
          ticks: {
            font: { size: 10 },
            callback: function(value) {
              return value >= 1000 ? (value/1000) + 'k' : value;
            }
          }
        }
      }
    }
  });
}

// Render transaction types chart
function renderTransactionTypesChart(transactions) {
  const ctx = document.getElementById('transactionTypesChart').getContext('2d');
  
  const deposits = transactions.filter(t => t.type === 'deposit').length;
  const withdrawals = transactions.filter(t => t.type === 'withdrawal').length;
  const services = transactions.filter(t => t.type === 'service').length;
  
  // Destroy existing chart
  if (transactionTypesChart) {
    transactionTypesChart.destroy();
  }
  
  const total = deposits + withdrawals + services;
  if (total === 0) {
    ctx.font = '14px Arial';
    ctx.fillStyle = '#64748b';
    ctx.textAlign = 'center';
    ctx.fillText('Hakuna data', ctx.canvas.width / 2, ctx.canvas.height / 2);
    return;
  }
  
  transactionTypesChart = new Chart(ctx, {
    type: 'pie',
    data: {
      labels: ['Amana', 'Kutoa', 'Huduma'],
      datasets: [{
        data: [deposits, withdrawals, services],
        backgroundColor: [
          'rgba(34, 197, 94, 0.8)',
          'rgba(239, 68, 68, 0.8)',
          'rgba(59, 89, 152, 0.8)'
        ],
        borderWidth: 0,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            usePointStyle: true,
            padding: 10,
            font: { size: 10 }
          }
        }
      }
    }
  });
}

// Render status chart
function renderStatusChart(pending, completed, rejected) {
  const ctx = document.getElementById('statusChart').getContext('2d');
  
  // Destroy existing chart
  if (statusChart) {
    statusChart.destroy();
  }
  
  const total = pending + completed + rejected;
  if (total === 0) {
    ctx.font = '14px Arial';
    ctx.fillStyle = '#64748b';
    ctx.textAlign = 'center';
    ctx.fillText('Hakuna data', ctx.canvas.width / 2, ctx.canvas.height / 2);
    return;
  }
  
  statusChart = new Chart(ctx, {
    type: 'pie',
    data: {
      labels: ['Inasubiri', 'Imekamilika', 'Imekataliwa'],
      datasets: [{
        data: [pending, completed, rejected],
        backgroundColor: [
          'rgba(245, 158, 11, 0.8)',
          'rgba(34, 197, 94, 0.8)',
          'rgba(239, 68, 68, 0.8)'
        ],
        borderWidth: 0,
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          position: 'bottom',
          labels: {
            usePointStyle: true,
            padding: 10,
            font: { size: 10 }
          }
        }
      }
    }
  });
}

// Render transactions list
function renderTransactionsList(transactions) {
  if (transactions.length === 0) {
    transactionsList.innerHTML = `
      <div class="empty-state">
        <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <rect width="20" height="14" x="2" y="5" rx="2"/>
          <line x1="2" x2="22" y1="10" y2="10"/>
        </svg>
        <p>Hakuna miamala bado</p>
      </div>
    `;
    return;
  }
  
  // Sort by date (newest first) and take top 10
  const sortedTransactions = [...transactions]
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
    .slice(0, 10);
  
  transactionsList.innerHTML = sortedTransactions.map(t => {
    const isDeposit = t.type === 'deposit';
    const date = new Date(t.createdAt).toLocaleDateString('sw-TZ', {
      day: 'numeric',
      month: 'short',
      year: 'numeric'
    });
    
    let statusClass = '';
    let statusText = '';
    if (t.status === 'pending') {
      statusClass = 'pending';
      statusText = 'Inasubiri';
    } else if (t.status === 'completed') {
      statusClass = 'completed';
      statusText = 'Imekamilika';
    } else {
      statusText = 'Imekataliwa';
    }
    
    return `
      <div class="transaction-item">
        <div class="transaction-left">
          <div class="transaction-icon ${isDeposit ? 'deposit' : 'withdrawal'}">
            ${isDeposit ? 
              '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>' :
              '<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m18 15-6-6-6 6"/></svg>'
            }
          </div>
          <div class="transaction-info">
            <h4>${isDeposit ? 'Amana' : t.type === 'withdrawal' ? 'Kutoa' : 'Huduma'}</h4>
            <p>${date}</p>
          </div>
        </div>
        <div class="transaction-right">
          <div class="transaction-amount ${isDeposit ? 'positive' : 'negative'}">
            ${isDeposit ? '+' : '-'}TSh ${formatNumber(t.amount)}
          </div>
          <div class="transaction-status ${statusClass}">${statusText}</div>
        </div>
      </div>
    `;
  }).join('');
}
