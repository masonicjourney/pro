// ImgBB API for image hosting
// Get your API key from https://api.imgbb.com/

const IMGBB_API_KEY = "YOUR_IMGBB_API_KEY"; // Replace with your API key

export interface ImgBBResponse {
  success: boolean;
  data?: {
    id: string;
    url: string;
    display_url: string;
    delete_url: string;
    thumb: {
      url: string;
    };
    medium?: {
      url: string;
    };
  };
  error?: {
    message: string;
  };
}

export async function uploadToImgBB(file: File): Promise<string> {
  const formData = new FormData();
  formData.append("image", file);
  formData.append("key", IMGBB_API_KEY);

  try {
    const response = await fetch("https://api.imgbb.com/1/upload", {
      method: "POST",
      body: formData,
    });

    const result: ImgBBResponse = await response.json();

    if (result.success && result.data) {
      return result.data.display_url;
    } else {
      throw new Error(result.error?.message || "Upload failed");
    }
  } catch (error) {
    console.error("ImgBB upload error:", error);
    throw error;
  }
}

export async function uploadBase64ToImgBB(base64String: string): Promise<string> {
  // Remove data URL prefix if present
  const base64Data = base64String.replace(/^data:image\/[a-z]+;base64,/, "");
  
  const formData = new FormData();
  formData.append("image", base64Data);
  formData.append("key", IMGBB_API_KEY);

  try {
    const response = await fetch("https://api.imgbb.com/1/upload", {
      method: "POST",
      body: formData,
    });

    const result: ImgBBResponse = await response.json();

    if (result.success && result.data) {
      return result.data.display_url;
    } else {
      throw new Error(result.error?.message || "Upload failed");
    }
  } catch (error) {
    console.error("ImgBB upload error:", error);
    throw error;
  }
}

// Convert file to base64 for preview
export function fileToBase64(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = (error) => reject(error);
  });
}
