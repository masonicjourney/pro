export interface User {
  id: string;
  fullName: string;
  email: string;
  password: string;
  phone: string;
  photoUrl: string;
  balanceTsh: number;
  balanceUsd: number;
  isActivated: boolean;
  registrationLeader: string;
  createdAt: string;
  updatedAt: string;
  lastLogin?: string;
  totalWithdrawals?: number;
  totalDeposits?: number;
}

export interface Admin {
  id: string;
  username: string;
  email: string;
  password: string;
  fullName: string;
  photoUrl: string;
  createdAt: string;
}

export interface Transaction {
  id: string;
  userId: string;
  type: 'withdrawal' | 'deposit' | 'id_request' | 'passport_request';
  amount: number;
  currency: 'TSh' | 'USD';
  status: 'pending' | 'processing' | 'completed' | 'failed';
  paymentMethod: string;
  accountNumber: string;
  createdAt: string;
  processedAt?: string;
  processedBy?: string;
}

export interface Bank {
  id: string;
  name: string;
  code: string;
  logo: string;
}

export interface MobilePayment {
  id: string;
  name: string;
  code: string;
  logo: string;
}

export const BANKS: Bank[] = [
  { id: 'crdb', name: 'CRDB Bank', code: 'CRDB', logo: '/banks/crdb.png' },
  { id: 'nmb', name: 'NMB Bank', code: 'NMB', logo: '/banks/nmb.png' },
  { id: 'nbc', name: 'NBC Bank', code: 'NBC', logo: '/banks/nbc.png' },
  { id: 'stanbic', name: 'Stanbic Bank', code: 'STANBIC', logo: '/banks/stanbic.png' },
  { id: 'dtb', name: 'DTB Bank', code: 'DTB', logo: '/banks/dtb.png' },
  { id: 'equity', name: 'Equity Bank', code: 'EQUITY', logo: '/banks/equity.png' },
  { id: 'absa', name: 'ABSA Bank', code: 'ABSA', logo: '/banks/absa.png' },
  { id: 'kcb', name: 'KCB Bank', code: 'KCB', logo: '/banks/kcb.png' },
  { id: 'exim', name: 'Exim Bank', code: 'EXIM', logo: '/banks/exim.png' },
  { id: 'azania', name: 'Azania Bank', code: 'AZANIA', logo: '/banks/azania.png' },
];

export const MOBILE_PAYMENTS: MobilePayment[] = [
  { id: 'mpesa', name: 'M-Pesa', code: 'MPESA', logo: '/mobile/mpesa.png' },
  { id: 'tigopesa', name: 'Tigo Pesa', code: 'TIGO', logo: '/mobile/tigopesa.png' },
  { id: 'airtel', name: 'Airtel Money', code: 'AIRTEL', logo: '/mobile/airtel.png' },
  { id: 'halopesa', name: 'Halo Pesa', code: 'HALO', logo: '/mobile/halopesa.png' },
  { id: 'ttcl', name: 'TTCL Pesa', code: 'TTCL', logo: '/mobile/ttcl.png' },
  { id: 'ezypesa', name: 'Ezy Pesa', code: 'EZY', logo: '/mobile/ezypesa.png' },
];

export const USD_RATE = 2650; // TSh per 1 USD
