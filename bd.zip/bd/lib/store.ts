'use client';

import type { User, Admin, Transaction } from './types';

const STORAGE_KEYS = {
  USERS: 'js_wallet_users',
  ADMINS: 'js_wallet_admins',
  TRANSACTIONS: 'js_wallet_transactions',
  CURRENT_USER: 'js_wallet_current_user',
  CURRENT_ADMIN: 'js_wallet_current_admin',
  ADMIN_SETUP_DONE: 'js_wallet_admin_setup',
};

// Helper to safely access localStorage
const getStorage = () => {
  if (typeof window !== 'undefined') {
    return window.localStorage;
  }
  return null;
};

// Users
export function getUsers(): User[] {
  const storage = getStorage();
  if (!storage) return [];
  const data = storage.getItem(STORAGE_KEYS.USERS);
  return data ? JSON.parse(data) : [];
}

export function saveUser(user: User): void {
  const storage = getStorage();
  if (!storage) return;
  const users = getUsers();
  const index = users.findIndex(u => u.id === user.id);
  if (index >= 0) {
    users[index] = user;
  } else {
    users.push(user);
  }
  storage.setItem(STORAGE_KEYS.USERS, JSON.stringify(users));
}

export function getUserById(id: string): User | null {
  const users = getUsers();
  return users.find(u => u.id === id) || null;
}

export function getUserByEmail(email: string): User | null {
  const users = getUsers();
  return users.find(u => u.email === email) || null;
}

export function getUserByPhone(phone: string): User | null {
  const users = getUsers();
  return users.find(u => u.phone === phone) || null;
}

export function loginUser(emailOrPhone: string, password: string): User | null {
  const users = getUsers();
  const user = users.find(u => 
    (u.email === emailOrPhone || u.phone === emailOrPhone) && u.password === password
  );
  
  if (user) {
    user.lastLogin = new Date().toISOString();
    saveUser(user);
    setCurrentUser(user);
  }
  
  return user || null;
}

// Current User Session
export function getCurrentUser(): User | null {
  const storage = getStorage();
  if (!storage) return null;
  const data = storage.getItem(STORAGE_KEYS.CURRENT_USER);
  return data ? JSON.parse(data) : null;
}

export function setCurrentUser(user: User | null): void {
  const storage = getStorage();
  if (!storage) return;
  if (user) {
    storage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
  } else {
    storage.removeItem(STORAGE_KEYS.CURRENT_USER);
  }
}

// Admins
export function getAdmins(): Admin[] {
  const storage = getStorage();
  if (!storage) return [];
  const data = storage.getItem(STORAGE_KEYS.ADMINS);
  return data ? JSON.parse(data) : [];
}

export function saveAdmin(admin: Admin): void {
  const storage = getStorage();
  if (!storage) return;
  const admins = getAdmins();
  const index = admins.findIndex(a => a.id === admin.id);
  if (index >= 0) {
    admins[index] = admin;
  } else {
    admins.push(admin);
  }
  storage.setItem(STORAGE_KEYS.ADMINS, JSON.stringify(admins));
}

export function getAdminByUsername(username: string): Admin | null {
  const admins = getAdmins();
  return admins.find(a => a.username === username) || null;
}

export function getAdminById(id: string): Admin | null {
  const admins = getAdmins();
  return admins.find(a => a.id === id) || null;
}

// Current Admin Session
export function getCurrentAdmin(): Admin | null {
  const storage = getStorage();
  if (!storage) return null;
  const data = storage.getItem(STORAGE_KEYS.CURRENT_ADMIN);
  return data ? JSON.parse(data) : null;
}

export function setCurrentAdmin(admin: Admin | null): void {
  const storage = getStorage();
  if (!storage) return;
  if (admin) {
    storage.setItem(STORAGE_KEYS.CURRENT_ADMIN, JSON.stringify(admin));
  } else {
    storage.removeItem(STORAGE_KEYS.CURRENT_ADMIN);
  }
}

// Admin Setup
export function isAdminSetupDone(): boolean {
  const storage = getStorage();
  if (!storage) return false;
  return storage.getItem(STORAGE_KEYS.ADMIN_SETUP_DONE) === 'true';
}

export function setAdminSetupDone(): void {
  const storage = getStorage();
  if (!storage) return;
  storage.setItem(STORAGE_KEYS.ADMIN_SETUP_DONE, 'true');
}

// Transactions
export function getTransactions(): Transaction[] {
  const storage = getStorage();
  if (!storage) return [];
  const data = storage.getItem(STORAGE_KEYS.TRANSACTIONS);
  return data ? JSON.parse(data) : [];
}

export function saveTransaction(transaction: Transaction): void {
  const storage = getStorage();
  if (!storage) return;
  const transactions = getTransactions();
  const index = transactions.findIndex(t => t.id === transaction.id);
  if (index >= 0) {
    transactions[index] = transaction;
  } else {
    transactions.push(transaction);
  }
  storage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
}

export function getTransactionsByUserId(userId: string): Transaction[] {
  const transactions = getTransactions();
  return transactions.filter(t => t.userId === userId);
}

export function updateUserBalance(userId: string, amountTsh: number, operation: 'add' | 'subtract'): User | null {
  const user = getUserById(userId);
  if (!user) return null;
  
  if (operation === 'add') {
    user.balanceTsh += amountTsh;
  } else {
    user.balanceTsh -= amountTsh;
  }
  
  user.balanceUsd = user.balanceTsh / 2650; // USD rate
  user.updatedAt = new Date().toISOString();
  saveUser(user);
  return user;
}

export function activateUser(userId: string): User | null {
  const user = getUserById(userId);
  if (!user) return null;
  
  user.isActivated = true;
  user.updatedAt = new Date().toISOString();
  saveUser(user);
  return user;
}

export function deactivateUser(userId: string): User | null {
  const user = getUserById(userId);
  if (!user) return null;
  
  user.isActivated = false;
  user.updatedAt = new Date().toISOString();
  saveUser(user);
  return user;
}

// Generate unique ID
export function generateId(): string {
  return Date.now().toString(36) + Math.random().toString(36).substr(2);
}
